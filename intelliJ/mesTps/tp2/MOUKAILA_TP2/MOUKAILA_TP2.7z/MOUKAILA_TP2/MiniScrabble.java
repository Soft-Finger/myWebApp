/**
 * Description: On veut développer un programme qui permet de s’entraîner au Scrabble
 * @author Yahaya Moukaila
 * Title: Mini-Scrabble
 * Date : 06-11-2020
 *
 */
 
public class MiniScrabble {

	public static void main(String[] args) {
		
		// Déclaration des constantes
		
        final String LISTE_DE_MOTS = "BALEINE, PLANETE, TABLEAU, PROGRAMMATION, VAISSELLE, TOURELLES, SUSPICION"
			+ ", VAINQUEUR, CREDIBLE, VAPOTEUSE, EXPERIENCE, VALENTINE, ABONDANCE, REFRAINS";

		// Déclaration des variables
        
        int nbMots = 0;
        int position;
        int comptVirgule = 0;
        int randomNumber = 1;
        int randPosition ;
        int nombreDeLettres = 0;
        int posLettreDonnee1 = 0;
        int posLettreDonnee2 = 0;
        int posPremiereLettre = 0;
        int posDerniereLettre = 0;
		int nbLettreResAMelanger;
        
        String mot;
        String temp = "";
        String lettresAMelanger = "";
        String lettresRestantesMelangees = "";
        

		System.out.println("\nMini-Scrabble");
		String reponse = "O";

		// BOUCLE DE RECOMMENCEMENT DU JEU

	   do{    
		   posLettreDonnee1 = 0;
		   posLettreDonnee2 = 0;
		   lettresRestantesMelangees = "";
		   comptVirgule = 0;
		   posPremiereLettre = 0;
		   posDerniereLettre = 0;

			// CHOISIR LE MOT
			
			for (int i = 1; i <= LISTE_DE_MOTS.length(); i++) {
				if (LISTE_DE_MOTS.charAt(i - 1) == ',') {				
					comptVirgule += 1;
				}
			}
			nbMots = comptVirgule + 1;
			
			//Gérération de mots aléatoires 
			
			randomNumber = (int)(Math.random() * nbMots);			
			
			//POSITION DE LA PREMIERE LETTRE DU MOT 
			
			comptVirgule = 0;
			posPremiereLettre = 0;
			
			for (position = 0; position < LISTE_DE_MOTS.length(); position++) {
				if (LISTE_DE_MOTS.charAt(position) == ',') {
					comptVirgule++;
					
					if(comptVirgule == randomNumber) { 
						posPremiereLettre = position + 2;
					break;
					}
				}
			}
			
			//POSITION DE LA DERNIERE LETTRE DU MOT
			
			posDerniereLettre = 0;
			
			for (int i = posPremiereLettre; i < LISTE_DE_MOTS.length(); i++) {
				if(LISTE_DE_MOTS.charAt(i) == ',') {
					posDerniereLettre = i;
					break;
				}else { 
					posDerniereLettre = LISTE_DE_MOTS.length();
				}
			}
			
			// EXTRACTION	
			
			mot = LISTE_DE_MOTS.substring(posPremiereLettre, posDerniereLettre);
			
			// A-NOMBRE DE LETTRES DU MOT CHOISI
			
			lettresAMelanger = mot;
			nombreDeLettres = mot.length();

			if(nombreDeLettres >= 1 && nombreDeLettres <= 7){
				
				randPosition = 0;
				lettresRestantesMelangees = ""; 
				nbLettreResAMelanger = lettresAMelanger.length();
				
				while (nbLettreResAMelanger >= 1) {
					randPosition = (int)(Math.random() * (nbLettreResAMelanger - 1));
					temp = "";
				
					for (int i = 0; i < nbLettreResAMelanger; i++) {
						if(i == randPosition) {
							lettresRestantesMelangees = lettresRestantesMelangees + lettresAMelanger.charAt(i);
						}else {
							temp = temp + lettresAMelanger.charAt(i);
						}
					}
					lettresAMelanger = temp;
					nbLettreResAMelanger = lettresAMelanger.length();
				}

				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("----");
				}
				System.out.println("-");
				
				// Les lettres ou les blancs
				
				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("| ");

						System.out.print("  ");
				}
				System.out.println("|");
				
				// La base
				
				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("----");
				}
				System.out.println("-");
			}
			
			if(nombreDeLettres >= 9){			
				posLettreDonnee1 = (int)(Math.random() * 7);
				
				//Extraction de la lettre donnée du mot a melanger 
				
				 temp = "";
				
				for (int i = 0; i < lettresAMelanger.length(); i++) {
					if(i == posLettreDonnee1) {						
						}else {
							temp = temp + lettresAMelanger.charAt(i);
						}
				}
				lettresAMelanger = temp;
				
				// GENERATION DE POSLETTREDONNE2
				
				posLettreDonnee2 = ((int)(Math.random() * ((nombreDeLettres - 1) - 6)) + 7);
				temp = "";
				
				for (int i = 0; i < lettresAMelanger.length(); i++) {
					if(i == posLettreDonnee2 - 1) {
						
						}else {
							temp = temp + lettresAMelanger.charAt(i);
						}
				}
				lettresAMelanger = temp;
				
				//QUESTION 3 : MELANGER LES LETTRE
				
				 lettresRestantesMelangees = ""; 
				
				 randPosition = 0;
				 nbLettreResAMelanger = lettresAMelanger.length();
				
				while (nbLettreResAMelanger >= 1) {
					randPosition = (int)(Math.random() * (nbLettreResAMelanger - 1));
					temp = "";
					
					for (int i = 0; i < nbLettreResAMelanger; i++) {
						if(i == randPosition) {
							lettresRestantesMelangees = lettresRestantesMelangees
							+ lettresAMelanger.charAt(i);
						}else {
							temp = temp + lettresAMelanger.charAt(i);
						}
					}
					lettresAMelanger = temp;
					nbLettreResAMelanger = lettresAMelanger.length();
				}
				// FIN QUESTION 3

				// Afficher les lettres qui sont données en indice, et des blancs pour les lettres à deviner.
				// L'en-tête
				
				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("----");
				}
				System.out.println("-");
				
				// Les lettres ou les blancs
				
				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("| ");

					if (i == posLettreDonnee1 || i == posLettreDonnee2)
						System.out.print(mot.charAt(i) + " ");
					else

						System.out.print("  ");
				}
				System.out.println("|");
				
				// La base
				
				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("----");
				}
				System.out.println("-");
			}//fin if supérieur ou égal à 9 mots

			if(nombreDeLettres == 8){

				// position lettre en indice
				
				temp = "";
				
				posLettreDonnee1 = (int)(Math.random() * 7);
				
				for(int i = 0;i < lettresAMelanger.length(); i++){
				 	if(i == posLettreDonnee1){ 
					
					}else{  
			   			temp = temp + lettresAMelanger.charAt(i);
			   		}
				}

				lettresAMelanger = temp;

				//MELANGE LES LETTRES RESTANTES
				
				lettresRestantesMelangees = ""; 
				randPosition = 0;
		  
				nbLettreResAMelanger = lettresAMelanger.length();

				while(nbLettreResAMelanger >= 1){
					randPosition = (int)(Math.random() * (nbLettreResAMelanger - 1));
				  	temp = "";

					for(int i = 0; i < lettresAMelanger.length(); i++){
						if(i == randPosition){
							lettresRestantesMelangees = lettresRestantesMelangees
							+ lettresAMelanger.charAt(i);
						}else{  
							temp = temp + lettresAMelanger.charAt(i);
						}
					}
					lettresAMelanger = temp;
					nbLettreResAMelanger = lettresAMelanger.length();
				}
				System.out.println();

				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("----");
				}
				
				System.out.println("-");
				
				// Les lettres ou les blancs
				
				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("| ");
					if (i == posLettreDonnee1)
						System.out.print(mot.charAt(i) + " ");
					else
						System.out.print("  ");
				}
				System.out.println("|");
				
				// La base
				
				for (int i = 0; i < nombreDeLettres; i++) {
					System.out.print("----");
				}
				System.out.println("-");
			}

			// Afficher les lettres restantes mélangées.
			// L'en-tête
			
			System.out.println("Vos lettres:");
			
			for (int i = 0; i < lettresRestantesMelangees.length(); i++) {
				System.out.print("----");
			}
			System.out.println("-");
			
			// Les lettres restantes
			
			for (int i = 0; i < lettresRestantesMelangees.length(); i++) {
				System.out.print("| " + lettresRestantesMelangees.charAt(i) + " ");
			}
			System.out.println("|");
			
			// La base
			
			for (int i = 0; i < lettresRestantesMelangees.length(); i++) {
				System.out.print("----");
			}
			System.out.println("-");

			// DEMANDER LA RÉPONSE AU JOUEUR (3 ESSAIS), ET CALCULER LE POINTAGE S'IL TROUVE LE BON MOT.

			int nombreEssai = 3;
			int pointUtilisateur = 0;
			
			char lettreDuMot;
			String motUtilisateur;
	 
			do{
				System.out.println("Il vous reste " + nombreEssai + " Essais");
				System.out.print("Entrez le mot :  ");
				motUtilisateur = Keyboard.readString();
				
				nombreEssai--;
				motUtilisateur = motUtilisateur.toUpperCase();
				
					if(nombreEssai > 0 && !mot.equals(motUtilisateur)){
						System.out.println("Mauvaise reponse, essayez de nouveau ");
					}
			}while(nombreEssai > 0 && !mot.equals(motUtilisateur));

			if(mot.equals(motUtilisateur)){
				for(int i = 0; i < mot.length(); i++){
					lettreDuMot = mot.charAt(i);

					if(lettreDuMot == 'A' || lettreDuMot == 'E' || 
						lettreDuMot == 'I' || lettreDuMot == 'L' ||
						lettreDuMot == 'N' || lettreDuMot == 'O' ||
						lettreDuMot == 'S' || lettreDuMot == 'R' || 
						lettreDuMot == 'U' || lettreDuMot == 'T'){
							
						pointUtilisateur = pointUtilisateur + 1;
					}

					if( lettreDuMot == 'D' || lettreDuMot == 'G' || lettreDuMot == 'M'){
						pointUtilisateur = pointUtilisateur + 2;
					}

					if( lettreDuMot == 'B' || lettreDuMot == 'C' || lettreDuMot == 'P'){
						pointUtilisateur = pointUtilisateur + 3;
					}

					if( lettreDuMot == 'F' || lettreDuMot == 'H' || lettreDuMot == 'V'){
						pointUtilisateur = pointUtilisateur + 4;
					}

					if( lettreDuMot == 'J' || lettreDuMot == 'Q' ){
						pointUtilisateur = pointUtilisateur + 5;
					}

					if( lettreDuMot == 'K' || lettreDuMot == 'W' || 
						lettreDuMot == 'X' || lettreDuMot == 'Y' ||
						lettreDuMot == 'Z'){

						pointUtilisateur = pointUtilisateur + 10;
					}
		 		}
				System.out.println("Bravo!!! vous avez fait " + pointUtilisateur + " points");
			}else{
				System.out.println("Mauvaise reponse, le mot est : " + mot);
			}

			//QUESTION 5 : GÉRER LE RECOMMENCEMENT DU JEU 

			System.out.print("Desirez-vous rejouer ? Entrer O pour rejouer , ou tout autre touche pour quitter : ");
			reponse = Keyboard.readString();

		}while(reponse.toUpperCase().equals("O"));

	}
}